package com.thenewboston.kevin;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;

public class GFXSurface extends Activity implements OnTouchListener {

	MyBringBackSurface ourSurfaceView;
	float x, y, sX, sY, fX, fY; // start and finishing x and y points
	float dX, dY, animateX, animateY, scaledX, scaledY; // dx = change in x
	Bitmap test, smile;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		ourSurfaceView = new MyBringBackSurface(this);
		ourSurfaceView.setOnTouchListener(this);
		x = 0;
		y = 0;
		sX = 0; sY = 0; fX = 0; fY = 0; 
		dX = dY = animateX = animateY = scaledX = scaledY = 0;
		test = BitmapFactory.decodeResource(getResources(), R.drawable.greenball);
		smile = BitmapFactory.decodeResource(getResources(), R.drawable.smile);
		setContentView(ourSurfaceView);
		
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		ourSurfaceView.pause(); // we have to create our own pause and resume methods in MyBringBackSurface.java
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		ourSurfaceView.resume();
	}

	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		
		try { // allows app to sleep every once in awhile
			Thread.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		x = event.getX();
		y = event.getY();
		
		switch(event.getAction())
		{
		case MotionEvent.ACTION_DOWN:
			sX = event.getX();
			sY = event.getY();
			dX = dY = animateX = animateY = scaledX = scaledY = 0; // once the mouse is pressed, reset variables to be recalculated for ball release
			fX = fY = 0;
			break;
		case MotionEvent.ACTION_UP:
			fX = event.getX();
			fY = event.getY();
			dX = fX-sX; dY = fY-sY;
			scaledX = dX/30; scaledY = dY/30;
			x = y = 0; // once the mouse is depressed, the left behind ball image will disappear.
			break;
		}
		
		
		return true; // loops endlessly in function, so need sleep method to use less processing.
	}
	
	
	public class MyBringBackSurface extends SurfaceView implements Runnable{

		SurfaceHolder ourHolder; 
		Thread ourThread = null;
		boolean isRunning = false; // ourThread goes to resume before it starts (runs)
		
		public MyBringBackSurface(Context context) {
			// TODO Auto-generated constructor stub
			super(context);
			ourHolder = getHolder(); // tells if the surface is valid to draw in and allows us to lock/unlock the canvas
			ourThread = new Thread(this); // by passing in this, we are using run method below
			ourThread.start();
		}

		public void pause()
		{
			isRunning = false;
			while(true)
			{
				try {
					ourThread.join(); // wait until ourThread dies
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			
			ourThread = null;
		}
		
		public void resume()
		{
			isRunning = true;
			ourThread = new Thread(this); 
			ourThread.start();
		}
		
		public void run() { // use the thread to animate our canvas
			// TODO Auto-generated method stub
			while(isRunning)
				{
					if(! ourHolder.getSurface().isValid())
					{
						continue;
					}
					Canvas canvas = ourHolder.lockCanvas(); // lock the canvas so no other threads can get to it and we start painting on the canvas that gets returned
					canvas.drawRGB(2, 2, 150); // draws the blue background
					
					if(x != 0  &&  y != 0) // don't draw the green ball in the beginning
					{
						canvas.drawBitmap(test, x - test.getWidth()/2, y - test.getHeight()/2, null); // to center the mouse on the ball
					}
					if(sX != 0  &&  sY != 0) 
					{
						canvas.drawBitmap(smile, sX - smile.getWidth()/2, sY - smile.getHeight()/2, null); // to center the mouse on the ball
					}
					if(fX != 0  &&  fY != 0) 
					{
						canvas.drawBitmap(test, fX - test.getWidth()/2-animateX, fY - test.getHeight()/2-animateY, null); // does the MOTION b/c animateX,Y is incremented every time 
						canvas.drawBitmap(smile, fX - smile.getWidth()/2, fY - smile.getHeight()/2, null); // to center the mouse on the ball
					}
					animateX = animateX + scaledX;
					animateY = animateY + scaledY;
					
					ourHolder.unlockCanvasAndPost(canvas); // posts the canvas for the world to see
				}
		}

	}

}
