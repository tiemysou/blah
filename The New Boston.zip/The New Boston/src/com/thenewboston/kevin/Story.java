package com.thenewboston.kevin;

public class Story {

	private String myName;
	private String myStoryText;
	private String myQuestions[];
	private String myAnswers[];
	private String myRandomAnswers[];
	
	Story(String name, String storyText, String[] questions, String[] answers, String[] randomAnswers)
	{
		myName = name;
		myStoryText = storyText;
		myQuestions = questions;
		myAnswers = answers;
		myRandomAnswers = randomAnswers;
	}
	
	String getName()
	{
		return myName;
	}
	String getStory()
	{
		return myStoryText;
	}
	String getQuestion(int index)
	{
		return myQuestions[index];
	}
	
	String getAnswer(int index)
	{
		return myAnswers[index];
	}
	String getRandomAnswer(int index)
	{
		return myRandomAnswers[index];
	}
	
	
}
